﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Array_File_Reader_Assignment
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void SelectionSort(int [] iArray)
        {
        int minIndex;
        int minValue;

            for (int startScan = 0; startScan < iArray.Length - 1; startScan++) 
            {
                minIndex = startScan;
                minValue = iArray[startScan];
                for (int index = startScan + 1; index < iArray.Length; index++)
                {
                    if (iArray[index] < minValue)
                    {
                        minValue = iArray[index];
                        minIndex = index;
                    }
                }
                Swap(ref iArray[minIndex], ref iArray[startScan]);
            }

        }
        private void Swap(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                const int SIZE = 5000;
                String[] Names = new string[SIZE];
                int index = 0;

                StreamReader inputFile;
                inputFile = File.OpenText("Names.csv");

                while (index < Names.Length && !inputFile.EndOfStream)
                {
                    Names[index] = inputFile.ReadLine();
                    index++;
                }

                inputFile.Close();

                foreach(string value in Names)
                {
                    listBox1.Items.Add(value);
                }
                
                
                
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void SelectionSort(string[] Names)
        {
            throw new NotImplementedException();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
     

        }
    }
}
