﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Array_File_Reader_Assignment
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        


        private void Form1_Load(object sender, EventArgs e)
        {

            int counter = 0;

            try
            {

                const int SIZE = 5000;
                String[] iArray = new string[SIZE];
                StreamReader source = new StreamReader("Names.csv");


                while (counter < iArray.Length && !source.EndOfStream)
                {
                    iArray[counter] = source.ReadLine();
                    counter++;
                }

                SelectionSort(iArray);

                source.Close();

                foreach (string value in iArray)
                {
                    listBox1.Items.Add(value);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void sortToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            int counter = 0;

            try
            {
                // Array variables
                const int SIZE = 5000;
                string[] iArray = new string[SIZE];
                StreamReader source = File.OpenText("Names.csv");

                while (counter < iArray.Length && !source.EndOfStream)
                {
                    iArray[counter] = source.ReadLine();
                    counter++;
                }

                SelectionSort(iArray);

                source.Close();

                foreach (string value in iArray)
                {
                    listBox1.Items.Add(value);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Swap(ref string a, ref string b)

        {
            string temp = a;
            a = b;
            b = temp;
        }

        private void SelectionSort(string[] iArray)
        {

            int minIndex;
            string minValue;

            for (int startScan = 0; startScan < iArray.Length - 1; startScan++)
            {
                minIndex = startScan;
                minValue = iArray[startScan];

                for (int index = startScan + 1; index < iArray.Length; index++)
                {
                    if (string.Compare(minValue, iArray[minIndex], true) == 1)
                    {
                        minValue = iArray[index];
                        minIndex = index;
                    }
                }

                Swap(ref iArray[minIndex], ref iArray[startScan]);

            }
        }

       



    }
}
        


  
    
