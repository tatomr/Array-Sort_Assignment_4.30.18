﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Array_File_Reader_Assignment
{
    public partial class Form1 : Form
    {

        const string pathFinder = "Names.csv";

        const int SIZE = 5000;
        string[] iArray = new string[SIZE];
        StreamReader source = File.OpenText("Names.csv");


        int counter;
        bool sort = false;

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            DateTime start = DateTime.Now;
            DateTime Finish;
            TimeSpan Time;
            counter = 0;

            try
            {

                // Increment my i variable
                for (counter = 0; counter < 5000; counter++)
                {
                    // Adds each line that my stream reader reads
                    // into the array instance of i
                    iArray[counter] = source.ReadLine();
                    // adds the instance of i into the list box
                    listBox1.Items.Add(iArray[counter]);

                }
                Finish = DateTime.Now;
                Time = Finish - start;

                label1.Text = listBox1.Items.Count.ToString() + " " + "Results Loaded in" + " " + (Time.TotalSeconds.ToString()) + " " + "seconds";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void SelectionSort(string[] iArray)
        {

            int minIndex;
            string minValue;

            for (int startScan = 0; startScan < iArray.Length - 1; startScan++)
            {
                minIndex = startScan;
                minValue = iArray[startScan];

                for (int index = startScan + 1; index < iArray.Length; index++)
                {
                    if (string.Compare(minValue, iArray[index], true) == 1)
                    {
                        minValue = iArray[index];
                        minIndex = index;
                    }
                }

                Swap(ref iArray[minIndex], ref iArray[startScan]);

            }
        }

        private void Swap(ref string a, ref string b)

        {
            string temp = a;
            a = b;
            b = temp;
        }
        private void sortToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            DateTime start = DateTime.Now;
            DateTime Finish;
            TimeSpan Time;

            try
            {


                while (counter < iArray.Length && !source.EndOfStream)
                {
                    iArray[counter] = source.ReadLine();
                    counter++;
                }
                listBox1.Items.Clear();
                SelectionSort(iArray);

                foreach (string value in iArray)
                {
                    listBox1.Items.Add(value);
                }

                Finish = DateTime.Now;
                Time = Finish - start;

                label2.Text = listBox1.Items.Count.ToString()
                    + " " + "Results Sorted in" + " " + (Time.TotalSeconds.ToString()) + " " + "seconds";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void exportToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string pathFinder2 = "sortedNames.csv";
            // Stream Writer to write the text files
            StreamWriter streamWriter = new StreamWriter(pathFinder2);
            // Writes the sorted values into the new file
            foreach (string name in listBox1.Items)
            {
                streamWriter.WriteLine(name.ToString());
            }

        }
        private int BinarySearch (string[] iArray, string value)
        {
           

            int first = 0;
            int last = iArray.Length - 1;
            int middle;
            int position = -1;
            bool found = false;

            while (!found && first <= last)
            {
                middle = (first + last) / 2;
                if (iArray[middle] == value)
                {
                    found = true;
                    position = middle;
                }
                else if (string.Compare(iArray[middle], value, false) > 0)
                {
                    last = middle - 1;
                }
                else
                {
                    first = middle + 1;

                }
                return position;
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
            {
               // BinarySearch();
            }

            //private int BinarySearch(int[] iARRAY, int value)
            //{
            //    return;
            //}

        }
    }

        


  
    
